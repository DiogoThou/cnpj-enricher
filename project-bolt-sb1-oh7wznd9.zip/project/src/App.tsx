import React, { useState, useEffect } from 'react';
import { Building2, Database, Settings, CheckCircle, Zap, Shield, Clock, AlertCircle } from 'lucide-react';

interface AppStatus {
  status: string;
  tokenStatus: string;
  features: string[];
  endpoints: Record<string, string>;
}

function App() {
  const [appStatus, setAppStatus] = useState<AppStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchAppStatus();
  }, []);

  const fetchAppStatus = async () => {
    try {
      const response = await fetch('/account');
      if (response.ok) {
        const data = await response.json();
        setAppStatus(data);
      } else {
        setError('Erro ao carregar status do app');
      }
    } catch (err) {
      setError('Erro de conexão');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-50 to-red-100 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <p className="text-red-600 text-lg">{error}</p>
          <button 
            onClick={fetchAppStatus}
            className="mt-4 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
          >
            Tentar novamente
          </button>
        </div>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Configurado': return 'text-green-600 bg-green-100';
      case 'connected': return 'text-green-600 bg-green-100';
      default: return 'text-yellow-600 bg-yellow-100';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-100">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex items-center justify-center mb-6">
              <div className="relative">
                <Building2 className="w-16 h-16 text-indigo-600 mr-4" />
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs font-bold">2.0</span>
                </div>
              </div>
              <div className="text-left">
                <h1 className="text-5xl font-bold text-gray-800">CNPJ Enricher</h1>
                <p className="text-lg text-indigo-600 font-semibold">Sistema Inteligente de Enriquecimento</p>
              </div>
            </div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Enriqueça empresas do HubSpot automaticamente com dados completos da Receita Federal, 
              usando tecnologia avançada de cache e tratamento de erros.
            </p>
          </div>

          {/* Status Cards */}
          <div className="grid md:grid-cols-4 gap-6 mb-12">
            <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500 transform hover:scale-105 transition-transform">
              <div className="flex items-center mb-3">
                <CheckCircle className="w-6 h-6 text-green-500 mr-2" />
                <h3 className="font-semibold text-gray-800">Status</h3>
              </div>
              <p className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(appStatus?.status || '')}`}>
                {appStatus?.status === 'connected' ? 'Conectado' : appStatus?.status}
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-blue-500 transform hover:scale-105 transition-transform">
              <div className="flex items-center mb-3">
                <Database className="w-6 h-6 text-blue-500 mr-2" />
                <h3 className="font-semibold text-gray-800">API CNPJ</h3>
              </div>
              <p className="text-gray-600">Receita Federal</p>
              <p className="text-sm text-blue-600 mt-1">Com cache inteligente</p>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-purple-500 transform hover:scale-105 transition-transform">
              <div className="flex items-center mb-3">
                <Settings className="w-6 h-6 text-purple-500 mr-2" />
                <h3 className="font-semibold text-gray-800">HubSpot</h3>
              </div>
              <p className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(appStatus?.tokenStatus || '')}`}>
                {appStatus?.tokenStatus}
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-indigo-500 transform hover:scale-105 transition-transform">
              <div className="flex items-center mb-3">
                <Zap className="w-6 h-6 text-indigo-500 mr-2" />
                <h3 className="font-semibold text-gray-800">Campo</h3>
              </div>
              <p className="text-gray-600">teste_cnpj</p>
              <p className="text-sm text-indigo-600 mt-1">Dados formatados</p>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-4">
                <Zap className="w-8 h-8 text-yellow-500 mr-3" />
                <h3 className="text-xl font-bold text-gray-800">Cache Inteligente</h3>
              </div>
              <p className="text-gray-600 leading-relaxed">
                Sistema de cache automático que evita consultas desnecessárias à API da Receita Federal, 
                melhorando performance e respeitando rate limits.
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-4">
                <Shield className="w-8 h-8 text-green-500 mr-3" />
                <h3 className="text-xl font-bold text-gray-800">Tratamento Robusto</h3>
              </div>
              <p className="text-gray-600 leading-relaxed">
                Sistema avançado de tratamento de erros com mensagens claras, códigos específicos 
                e sugestões de solução para cada tipo de problema.
              </p>
            </div>

            <div className="bg-white rounded-xl shadow-lg p-8 hover:shadow-xl transition-shadow">
              <div className="flex items-center mb-4">
                <Clock className="w-8 h-8 text-blue-500 mr-3" />
                <h3 className="text-xl font-bold text-gray-800">Rate Limiting</h3>
              </div>
              <p className="text-gray-600 leading-relaxed">
                Controle automático de velocidade das requisições para respeitar os limites 
                da API CNPJ e garantir funcionamento estável.
              </p>
            </div>
          </div>

          {/* Main Content */}
          <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
            <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">
              Como usar o CNPJ Enricher 2.0
            </h2>

            <div className="space-y-8">
              <div className="flex items-start space-x-6">
                <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-lg">1</span>
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-800 mb-3">
                    Criar campo teste_cnpj
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Primeiro, crie o campo personalizado no HubSpot onde todos os dados serão salvos
                  </p>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <code className="text-sm text-gray-800 font-mono">
                      POST /api/create-test-field
                    </code>
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-lg">2</span>
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-800 mb-3">
                    Criar empresa de teste
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Crie uma empresa de exemplo com CNPJ válido para testar o sistema
                  </p>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <code className="text-sm text-gray-800 font-mono">
                      POST /api/create-test-company
                    </code>
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-6">
                <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-lg">3</span>
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-800 mb-3">
                    Enriquecer empresa
                  </h3>
                  <p className="text-gray-600 mb-4">
                    Use o ID da empresa para buscar e salvar todos os dados da Receita Federal
                  </p>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <code className="text-sm text-gray-800 font-mono">
                      POST /api/enrich<br />
                      {"{"}"companyId": "ID_DA_EMPRESA"{"}"}
                    </code>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-12 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
              <h4 className="font-semibold text-blue-800 mb-4 text-lg">
                📋 Dados salvos no campo teste_cnpj:
              </h4>
              <div className="grid md:grid-cols-2 gap-4">
                <ul className="text-sm text-blue-700 space-y-2">
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                    Razão Social e Nome Fantasia
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                    Situação Cadastral e Porte
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                    Endereço completo formatado
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                    Telefone e Email de contato
                  </li>
                </ul>
                <ul className="text-sm text-blue-700 space-y-2">
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                    Atividade Principal e CNAE
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                    Capital Social e Natureza Jurídica
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                    Lista completa de sócios
                  </li>
                  <li className="flex items-center">
                    <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                    Data de atualização dos dados
                  </li>
                </ul>
              </div>
            </div>

            <div className="mt-8 text-center">
              <a 
                href="/settings" 
                className="inline-flex items-center px-8 py-4 bg-gradient-to-r from-indigo-500 to-purple-600 text-white font-semibold rounded-lg hover:from-indigo-600 hover:to-purple-700 transition-all transform hover:scale-105 shadow-lg"
              >
                <Settings className="w-5 h-5 mr-2" />
                Acessar Configurações
              </a>
            </div>
          </div>

          {/* API Endpoints */}
          {appStatus?.endpoints && (
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h3 className="text-2xl font-bold text-gray-800 mb-6">🔗 Endpoints Disponíveis</h3>
              <div className="grid md:grid-cols-2 gap-4">
                {Object.entries(appStatus.endpoints).map(([name, endpoint]) => (
                  <div key={name} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <span className="font-medium text-gray-700 capitalize">
                      {name.replace(/([A-Z])/g, ' $1').trim()}
                    </span>
                    <code className="text-sm bg-gray-200 px-3 py-1 rounded text-gray-800">
                      {endpoint}
                    </code>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;